package it.unive.dais.cevid.datadroid.template;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.google.android.gms.maps.model.LatLng;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import it.unive.dais.cevid.datadroid.lib.parser.CsvRowParser;
import it.unive.dais.cevid.datadroid.lib.util.MapItem;

public class ListActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);


        int f = Integer.parseInt(getIntent().getStringExtra("fuf"));;
        boolean fif = false;

        if(f == 99){
            fif = true;
        }

        final ListView mylist = (ListView) findViewById(R.id.lv1);

        try {
            InputStream is = getResources().openRawResource(R.raw.data);
            CsvRowParser p = new CsvRowParser(new InputStreamReader(is), true, ",");
            List<CsvRowParser.Row> rows = p.getAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR).get();
            ArrayList<MapItem> lista = new ArrayList<>();
            ArrayList<String> codice = new ArrayList<>();
            for (final CsvRowParser.Row r : rows) {
                if (Integer.parseInt(r.get("codice_tipologia")) == f || fif ) {
                    codice.add( "\n"+ r.get("codice_intervento") + "\n \n" + r.get("oggetto") + "\n \n Tipologia: " + r.get("tipologia") + "\n \n Importo: " + r.get("importo") + " Euro \n");
                }

            }
            final ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, codice);
            mylist.setAdapter(adapter);

        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }






    }


}
