package it.unive.dais.cevid.datadroid.template;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class IntroActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intro);
        Button b = (Button) findViewById(R.id.button2);
        Button f = (Button) findViewById(R.id.button4);
        b.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),MapsActivity.class);
                startActivity(i);
            }
        });

        f.setOnClickListener(new View.OnClickListener() {


            public void onClick(View v) {
                Intent i = new Intent(getApplicationContext(),TutorialActivity.class);
                startActivity(i);
            }
        });

    }
    }

