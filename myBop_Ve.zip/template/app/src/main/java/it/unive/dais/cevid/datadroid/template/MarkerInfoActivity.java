package it.unive.dais.cevid.datadroid.template;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.model.LatLng;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

import it.unive.dais.cevid.datadroid.lib.parser.CsvRowParser;
import it.unive.dais.cevid.datadroid.lib.util.MapItem;

public class MarkerInfoActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_marker_info);


        int codice = Integer.parseInt(getIntent().getStringExtra("codice"));;




        try {
            InputStream is = getResources().openRawResource(R.raw.data);
            CsvRowParser p = new CsvRowParser(new InputStreamReader(is), true, ",");
            List<CsvRowParser.Row> rows = p.getAsyncTask().executeOnExecutor(AsyncTask.THREAD_POOL_EXECUTOR).get();
            List<MapItem> l = new ArrayList<>();
            for (final CsvRowParser.Row r : rows) {
                if (Integer.parseInt(r.get("codice_intervento")) == codice ) {

                    TextView b = (TextView) findViewById(R.id.textView8);
                    b.setText(r.get("oggetto"));
                    TextView c = (TextView) findViewById(R.id.textView10);
                    c.setText(r.get("importo") + " €");
                    TextView d = (TextView) findViewById(R.id.textView12);
                    d.setText(r.get("municipalità"));
                    TextView e = (TextView) findViewById(R.id.textView13);
                    e.setText(r.get("tipologia"));
                    TextView f = (TextView) findViewById(R.id.textView16);
                    f.setText(r.get("categoria"));
                    TextView g = (TextView) findViewById(R.id.textView18);
                    g.setText(r.get("finalita"));



                    break;

                }





            }
        } catch (InterruptedException | ExecutionException e) {
            e.printStackTrace();
        }
    }























    }

